function varargout = Tugas5_123180092(varargin)
%TUGAS5_123180092 MATLAB code file for Tugas5_123180092.fig
%      TUGAS5_123180092, by itself, creates a new TUGAS5_123180092 or raises the existing
%      singleton*.
%
%      H = TUGAS5_123180092 returns the handle to a new TUGAS5_123180092 or the handle to
%      the existing singleton*.
%
%      TUGAS5_123180092('Property','Value',...) creates a new TUGAS5_123180092 using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to Tugas5_123180092_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      TUGAS5_123180092('CALLBACK') and TUGAS5_123180092('CALLBACK',hObject,...) call the
%      local function named CALLBACK in TUGAS5_123180092.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Tugas5_123180092

% Last Modified by GUIDE v2.5 12-Mar-2020 14:18:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Tugas5_123180092_OpeningFcn, ...
                   'gui_OutputFcn',  @Tugas5_123180092_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Tugas5_123180092 is made visible.
function Tugas5_123180092_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for Tugas5_123180092
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Tugas5_123180092 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Tugas5_123180092_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
input1=get(handles.edit1,'string');
input2=get(handles.edit2,'string');
input3=get(handles.edit3,'string');
ipk=str2double(input1);
lamastudi=str2double(input2);
organisasi=str2double(input3);
training = [3.81 3.5 5; 3 7 1; 3.67 4.1 3; 3.32 3.8 5; 3 5 2; 3.20 4 4; 2.75 6 3; 3 5 5; 2.52 7 0; 3.47 4.6 7;3.9 4.2 2];
group = [4;2;4;3;2;3;1;2;1;3;4];
sampel=[ipk lamastudi organisasi];
mdl=fitcknn(training,group,'NumNeighbors',10);
[klasifikasi]=predict(mdl,sampel);
if(klasifikasi==1)
    hasil="Cukup";
end
if(klasifikasi==2)
    hasil="Baik";
end
if(klasifikasi==3)
    hasil="Memuaskan";
end
if(klasifikasi==4)
    hasil="Istimewa";
end
set(handles.text2,'string',(hasil));
